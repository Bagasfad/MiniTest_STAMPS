// Check dan skip Bilangan Prima
func CheckPrimeNumber(_ number: Int) -> Bool {
    // Bukan Dibawah 0
    if number <= 1 {
        return false
    }
    // Bukan dibawah 3
    if number <= 3 {
        return true
    }
    // Jika angka bisa dibagi 2 dan  dan hasilnya 0 Maka salah
    if number % 2 == 0 || number % 3 == 0 {
        return false
    }
    var i = 5
    while i * i <= number {
        if number % i == 0 || number % (i + 2) == 0 {
            return false
        }
        i += 6
    }
    return true
}

var NumbersofArray = [String]()

for i in (1...100).reversed() {
    if CheckPrimeNumber(i) {
        continue
        // Jika dapat dibagi 3 ganti dengan text "Foo"
    } else if i % 3 == 0{
        NumbersofArray.append("Foo")
        // Jika dapat dibagi 5 ganti dengan text "Bar"
    } else if i % 5 == 0 {
        NumbersofArray.append("Bar")
         // Jika dapat dibagi 3 dan 5 ganti dengan text "FooBar"
    } else if i % 3 == 0 && i % 5 == 0 {
        NumbersofArray.append("FooBar")
    } else {
        NumbersofArray.append(String(i))
    }
}

print(NumbersofArray)

