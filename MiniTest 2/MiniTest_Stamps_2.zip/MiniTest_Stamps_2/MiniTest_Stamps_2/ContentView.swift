//
//  ContentView.swift
//  MiniTest_Stamps_2
//
//  Created by Bagas Fadilla on 01/09/23.
//

import SwiftUI
import UIKit
import Alamofire
import SwiftyJSON

struct ContentView: View {
    //@State private var weatherForecast: [WeatherData] = []
    @ObservedObject var weatherManager = WeatherForecastManager()
    
    var body: some View {
        NavigationView {
            VStack {
                Text("For the city of Jakarta in the next 5 days")
                    .font(.title2)
                    .fontWeight(.light)
                
                List(weatherManager.weatherForecast) { weather in
                    VStack(alignment: .leading) {
                        Text(weather.day)
                            .font(.headline)
                        //Text(weather.date)
                        Text(weather.temperature)
                    }// vstack
                }// list
                .navigationBarTitle("Weather Forecast")
                Text("Created by Bagas Fadilla")
                .onAppear(perform:{weatherManager.fetchWeatherForecast()})
                }
            }// Vstack
        }// NavigationView
        
    }
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
