//
//  MiniTest_Stamps_2App.swift
//  MiniTest_Stamps_2
//
//  Created by Bagas Fadilla on 01/09/23.
//

import SwiftUI

@main
struct MiniTest_Stamps_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
