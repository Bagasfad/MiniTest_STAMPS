//
//  WeatherModel.swift
//  MiniTest_Stamps_2
//
//  Created by Bagas Fadilla on 01/09/23.
//

import Foundation

struct WeatherData: Identifiable {
    let id = UUID()
    let day: String
    let date: String
    let temperature: String
}
