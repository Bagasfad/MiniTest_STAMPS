//
//  WeatherAPI.swift
//  MiniTest_Stamps_2
//
//  Created by Bagas Fadilla on 01/09/23.
//

import Foundation
import Alamofire
import SwiftyJSON

class WeatherForecastManager: ObservableObject {
    
    @Published var weatherForecast: [WeatherData] = []
    
    
    func fetchWeatherForecast() {
        let APIKey = "1eaed70d5f4ba0425e540b7848fd5aad"
        let cityName = "Jakarta"
        let URL = "https://api.openweathermap.org/data/2.5/forecast?q=\(cityName)&appid=\(APIKey)"
        
        // URL Request from Openweather API
        AF.request(URL).responseJSON { response in 
            switch response.result {
            case .success(let data):
                
                //Parse JSON
                let json = JSON(data)
                
                //Menyimpan data dalam bentuk array
                var weatherData: [WeatherData] = []
                
                var previousDay = ""
                
                //Membuat list dari JSON
                for i in 0..<json["list"].count {
                    if let timestamp = json["list"][i]["dt"].double {
                        //Untuk mengetahui tanggal
                        let date = Date(timeIntervalSince1970: timestamp)
                        
                        //Format tanggal Friday, 1 September 2023
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "EEEE, d MMMM yyyy"
                        
                        let day = dateFormatter.string(from: date)
                        
                        // Check hari supaya tidak sama
                        if day != previousDay {
                            if let temperature = json["list"][i]["main"]["temp"].double {
                                
                                //Convert ke celcius karena default openweather kelvin
                                let temperatureCelsius = temperature - 273.15
                                let temperatureString = String(format: "Temperature: %.1f°C", temperatureCelsius)
                                
                                //Membuat data final
                                let weather = WeatherData(day: day, date: dateFormatter.string(from: date), temperature: temperatureString)
                                
                                //untuk menjadikan weather data menjadi array
                                weatherData.append(weather)
                                
                            }// if temperature
                        }// if day
                        
                        //update hari
                        previousDay = day
                    }// if timestamp
                }// for
                
                // Untuk menampilkan 5 hari berikutnya
                return self.weatherForecast = Array(weatherData.prefix(6))
            
                //handle error
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}
